document.getElementById('main-action').onclick = function () {
    document.getElementById('cars').scrollIntoView({behavior:"smooth"});
}

let buttons = document.getElementsByClassName('car-button');
for (let i=0; i<buttons.length; i++) {
    buttons[i].onclick = function () {
        document.getElementById('price').scrollIntoView({behavior:"smooth"});
    }
}

// buttons.forEach ( onclick = function () {
//     document.getElementById('price').scrollIntoView({behavior:"smooth"});
// });

function ValidatePhoneNumber(phoneNumber) {
    return (phoneNumber.match(/^[\d\+][\d\(\)\ -]{4,14}\d$/)); 
}

document.getElementById('price-action').onclick = function () {
    console.log(document.getElementById('price-action'));
    let name = document.getElementById('name').value.trim();
    let phone = document.getElementById('phone').value.trim();
    let car = document.getElementById('car').value.trim();
    if (name==='') {
        alert('Заполните поле имя!')
    } else {
        if (phone==='') {
            alert('Заполните поле номера телефона!');
        } else {
            if (!ValidatePhoneNumber(phone)) {
                alert('Введенный номер телефона не корректен!');
            } else {
                if (car==='') {
                    alert('Заполните поле типа заказываемой машины!');
                } else {
                    alert('Спасибо за заявку. Мы свяжемся с вами в ближайшее время');
                }
            }
        }
    }
}